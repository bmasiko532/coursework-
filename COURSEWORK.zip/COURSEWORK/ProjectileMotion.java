
package com.mycompany.question1;
import java.util.Scanner;

public class ProjectileMotion {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        final double g=9.8;
        
        System.out.print("Enter initial velocity (m/s):");
        double u = scanner.nextDouble();
        
        System.out.print("Enter lauch angle(degrees):");
        double angleDegrees = scanner.nextDouble();
        
        
        double angleRadians = Math.toRadians(angleDegrees);
        
        
        double timeofflight=(2*u*Math.sin(angleRadians))/g;
        double maxHeight=(u*u*Math.pow(Math.sin(angleRadians),2))/(2*g);
        double range = (u*u*Math.sin(2*angleRadians))/g;
        
       
        System.out.printf("Time of Flight:%2f seconds%n",timeofflight);
        System.out.printf("MaximumHeight:%2f meters%n",maxHeight);
        System.out.printf("Horizontal Range: %2f meters%n",range);
        
        scanner.close();
        
    }
}
